#ifndef __VERSION_H
#define __VERSION_H
/*===========================================================================*/
/**
    @file    version.h

    @brief   Version of the tool to manually set at each release.

@verbatim
=============================================================================

              Freescale Semiconductor Confidential Proprietary
        (c) Freescale Semiconductor, Inc. 2011-2015. All rights reserved.

Presence of a copyright notice is not an acknowledgement of
publication. This software file listing contains information of
Freescale Semiconductor, Inc. that is of a confidential and
proprietary nature and any viewing or use of this file is prohibited
without specific written permission from Freescale Semiconductor, Inc.

=============================================================================
Portability:

These definitions are customised for 32 bit cores of either endianness.

=============================================================================
@endverbatim */

#define CST_VERSION "BLN_CST_MAIN_02.03.00"

#endif /* __VERSION_H */
